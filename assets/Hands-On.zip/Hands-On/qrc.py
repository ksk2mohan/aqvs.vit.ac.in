import os
import numpy as np
import tensorflow as tf
from keras.datasets import mnist
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.svm import SVC, LinearSVC
from sklearn.metrics import accuracy_score
import bloqade
from bloqade.analog.ir.location import Chain, start

#Main function for building quantum tasks.
def build_task(QRC_parameters, xs1):
    natoms=QRC_parameters["atom_number"]
    encoding_scale=QRC_parameters["encoding_scale"]
    dt=QRC_parameters["total_time"]/QRC_parameters["time_steps"]
    #builds global Rabi and detuning pulses
    rabi_oscillations_program = (QRC_parameters["geometry_spec"]
            .rydberg.rabi.amplitude.uniform.constant(
                duration="run_time", value=QRC_parameters["rabi_frequency"]
            )
            .detuning.uniform.constant(duration="run_time", value=encoding_scale/2)
            #adds local detuning according to the feature vector
            .scale(list(xs1)).constant(duration="run_time", value=-encoding_scale)
            ) 
    rabi_oscillation_job = rabi_oscillations_program.batch_assign(run_time=np.arange(1, QRC_parameters["time_steps"]+1, 1)*dt)
    #`batch_assign` used to probe the quantum reservoir at set number of timesteps
    return rabi_oscillation_job

#To obtain the embeddings, we process the report containing the collected samples into embeddins made of Z and ZZ observables.
def process_results(QRC_parameters, report):  
    embedding=[]
    natoms=QRC_parameters["atom_number"]
    try:
        for t in range(QRC_parameters["time_steps"]):
            ar1=-1.0+2*((report.bitstrings())[t])
            nsh1=ar1.shape[0]
            for i in range(natoms):
                embedding.append(np.sum(ar1[:,i])/nsh1) #Z expectation values
            if QRC_parameters["readouts"]=="ZZ":
                for i in range(natoms):
                    for j in range(i+1,natoms):
                        embedding.append(np.sum(ar1[:,i]*ar1[:,j])/nsh1) #ZZ expectation values
    except: #In case no experimental results were obtained.
        print("No results exist.")
        for t in range(QRC_parameters["time_steps"]):
            for i in range(natoms):
                embedding.append(0.0)
            if QRC_parameters["readouts"]=="ZZ":
                for i in range(natoms):
                    for j in range(i+1,natoms):
                        embedding.append(0.0)
    return embedding

#Processing if only samples are needed.
def process_results_samples(QRC_parameters, report):  
    embedding=[]
    natoms=QRC_parameters["atom_number"]
    try:
        embedding=report.bitstrings()
        # for t in range(QRC_parameters["time_steps"]):
        #     ar1=-1.0+2*((report.bitstrings())[t])
        #     nsh1=ar1.shape[0]
        #     for i in range(natoms):
        #         embedding.append(np.sum(ar1[:,i])/nsh1) #Z expectation values
        #     if QRC_parameters["readouts"]=="ZZ":
        #         for i in range(natoms):
        #             for j in range(i+1,natoms):
        #                 embedding.append(np.sum(ar1[:,i]*ar1[:,j])/nsh1) #ZZ expectation values
    except: #In case no experimental results were obtained.
        print("No results exist.")
        for t in range(QRC_parameters["time_steps"]):
            for i in range(natoms):
                embedding.append(0.0)
            if QRC_parameters["readouts"]=="ZZ":
                for i in range(natoms):
                    for j in range(i+1,natoms):
                        embedding.append(0.0)
    return embedding

def get_embeddings_emulation(xs, num_examples, nshots=1000):
    return np.array([process_results(QRC_parameters, 
        build_task(QRC_parameters, xs[data,:]).bloqade.python().run(shots=nshots, rtol=1e-8, atol=1e-8).report())
        for data in range(num_examples)])

# Download the MNIST dataset and rescaling data
                     
(train_X, train_y), (test_X, test_y) = mnist.load_data()
train_X, test_X = train_X / 255.0, test_X / 255.0

## training data set (each image has 28x28 pixels and there are 60000 training samples)
print('X_train: ' + str(train_X.shape))
print('Y_train: ' + str(train_y.shape))

## test data set (10000 test samples)
print('X_test:  '  + str(test_X.shape))
print('Y_test:  '  + str(test_y.shape))
# example of an training dataset image for '5'
plt.imshow(train_X[0], cmap=plt.get_cmap('gray'), interpolation='None')
plt.axis('off')
plt.show()

# We first use PCA to downsample the data into 10-dimensional vectors
dim_pca = 8

# Use the `fit` function from the `sklearn` package to define the PCA model and apply to training set
pca=PCA(n_components=dim_pca).fit(np.reshape(train_X, (60000,28*28)))
x=pca.transform(np.reshape(train_X, (60000,28*28)))

# Let us see how it looks
num_examples = 1000
xs = x[:num_examples,:]
print("Training set PCA: \n ", xs[0:5,:], "\n")

#processing the test set
xt=pca.transform(np.reshape(test_X, (10000,28*28)))

# Let us see how it looks
num_test_examples = 200
xs_test = xt[:num_test_examples,:]
print("Test set PCA: \n ", xs[0:5,:], "")

spectral =(np.amax(xs) - np.amin(xs))
m1=np.amin(xs)
xs = (xs - m1)/spectral # to make sure values to be between [0, 1]
xs_test = (xs_test - m1)/spectral # the same transformation on the test set

QRC_parameters={
    "atom_number":dim_pca, #number of atoms, equal to the dimension of PCA feature vector
    "geometry_spec":Chain(dim_pca, lattice_spacing=10), #atom geometry - we will use a linear chain with 10 micron distance between atoms
    "encoding_scale":9.0, #scaling factor for local detuning encoding
    "rabi_frequency":6.283,#value of Rabi frequency used
    "total_time":4, #total maximum evolution time - 4 microseconds
    "time_steps":8, #number of probe times for quantum embedding collection - 8 in the 4 microsecond window
    "readouts":"ZZ", #includes both ZZ correlators together with default Rydberg density as generated embeddings
}

embeddings=get_embeddings_emulation(xs, num_examples, nshots=1000)
test_embeddings=get_embeddings_emulation(xs_test, num_test_examples, nshots=1000)

print(embeddings.shape)
print(test_embeddings.shape)

#building a linear model
model = tf.keras.Sequential([
    tf.keras.layers.Dense(10)
    ])
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.1),
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])

#fitting to train data
model.fit(xs, train_y[:num_examples], epochs=1000, batch_size=100, verbose=0)

#evaluating on test data
test_loss, test_acc = model.evaluate(xs_test,  test_y[:num_test_examples], verbose=0)
print('PCA test accuracy:', 100*round(test_acc, 2), "%")

#building a linear model
#we include regularization and tune epsilon parameter of the optimizer to better control training from QRC embeddings generated on finite number of samples
model = tf.keras.Sequential([
    tf.keras.layers.Dense(10, kernel_regularizer=tf.keras.regularizers.L1(l1=0.0001))
    ])
model.compile(optimizer=tf.keras.optimizers.Adam(epsilon=0.0002),
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])

#fitting to train data
model.fit(embeddings, train_y[:num_examples], epochs=2000, batch_size=100, verbose=0)

#evaluating on test data
test_loss, test_acc = model.evaluate(test_embeddings,  test_y[:num_test_examples], verbose=0)
print('QRC test accuracy:', 100*round(test_acc, 2), "%")

model = tf.keras.Sequential([
    tf.keras.layers.Dense(50, activation='relu'),
    tf.keras.layers.Dense(50, activation='relu'),
    tf.keras.layers.Dense(10),

    ])
model.compile(optimizer=tf.keras.optimizers.Adam(),
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])
model.fit(xs, train_y[:num_examples], epochs=1000, batch_size=100, verbose=0)
test_loss, test_acc = model.evaluate(xs_test,  test_y[:num_test_examples], verbose=0)
print('4-layer NN test accuracy:', 100*round(test_acc, 2), "%")

#The same implemented with LinearSVC and SVC from sklearn.

svm = LinearSVC(C=1.0, multi_class='crammer_singer', dual=False)
svm.fit(xs, train_y[:num_examples])
y_pred = svm.predict(xs_test)
accuracy=svm.score(xs_test, test_y[:num_test_examples])
print('Linear SVM test accuracy:', 100*round(accuracy, 2), "%")

svm = SVC(C=8.)
svm.fit(xs, train_y[:num_examples])
y_pred = svm.predict(xs_test)
accuracy=svm.score(xs_test, test_y[:num_test_examples])
print('SVC test accuracy (rbf kernel):', 100*round(accuracy, 2), "%")


svm = LinearSVC(C=1.0, multi_class='crammer_singer', dual=False)
svm.fit(embeddings, train_y[:num_examples])
y_pred = svm.predict(embeddings)
accuracy=svm.score(test_embeddings, test_y[:num_test_examples])
print('QRC test accuracy:', 100*round(accuracy, 2), "%")