import torch
import torch.nn as nn
import torch.optim as optim

# -------------------------------
# Device
# -------------------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# -------------------------------
# Neural Network
# -------------------------------
class QPINN(nn.Module):
    def __init__(self, input_dim=2, hidden_dim=64, output_dim=2, num_hidden_layers=3):
        super().__init__()

        layers = []
        layers.append(nn.Linear(input_dim, hidden_dim))
        layers.append(nn.Tanh())

        for _ in range(num_hidden_layers):
            layers.append(nn.Linear(hidden_dim, hidden_dim))
            layers.append(nn.Tanh())

        layers.append(nn.Linear(hidden_dim, output_dim))
        self.model = nn.Sequential(*layers)

    def forward(self, x, t):
        inputs = torch.cat([x, t], dim=1)
        output = self.model(inputs)
        u = output[:, 0:1]  # Real part
        v = output[:, 1:2]  # Imaginary part
        return u, v


# -------------------------------
# Helper: gradients
# -------------------------------
def grad(outputs, inputs):
    return torch.autograd.grad(
        outputs,
        inputs,
        grad_outputs=torch.ones_like(outputs),
        create_graph=True,
        retain_graph=True
    )[0]


# -------------------------------
# Physics residual for
# i dψ/dt = -1/2 d²ψ/dx²
#
# If ψ = u + iv, then:
# u_t = -1/2 v_xx
# v_t =  1/2 u_xx
# -------------------------------
def schrodinger_residual(model, x, t):
    x.requires_grad_(True)
    t.requires_grad_(True)

    u, v = model(x, t)

    u_t = grad(u, t)
    v_t = grad(v, t)

    u_x = grad(u, x)
    v_x = grad(v, x)

    u_xx = grad(u_x, x)
    v_xx = grad(v_x, x)

    # Residuals
    f_u = u_t + 0.5 * v_xx
    f_v = v_t - 0.5 * u_xx

    return f_u, f_v, u, v


# -------------------------------
# Initial condition
# Example Gaussian wave packet at t=0
# ψ(x,0) = exp(-x^2) + 0i
# -------------------------------
def initial_condition(x):
    u0 = torch.exp(-x**2)
    v0 = torch.zeros_like(x)
    return u0, v0


# -------------------------------
# Training data
# -------------------------------
# Collocation points inside domain
N_f = 2000
x_f = -5 + 10 * torch.rand(N_f, 1, device=device)
t_f = torch.rand(N_f, 1, device=device)

# Initial condition points at t=0
N_i = 200
x_i = -5 + 10 * torch.rand(N_i, 1, device=device)
t_i = torch.zeros(N_i, 1, device=device)
u_i, v_i = initial_condition(x_i)

# Boundary condition points (simple zero boundary)
N_b = 200
t_b = torch.rand(N_b, 1, device=device)
x_b_left = -5 * torch.ones(N_b, 1, device=device)
x_b_right = 5 * torch.ones(N_b, 1, device=device)

# -------------------------------
# Model and optimizer
# -------------------------------
model = QPINN().to(device)
optimizer = optim.Adam(model.parameters(), lr=1e-3)
mse = nn.MSELoss()

# -------------------------------
# Training loop
# -------------------------------
epochs = 1000

for epoch in range(epochs):
    optimizer.zero_grad()

    # Physics loss
    f_u, f_v, _, _ = schrodinger_residual(model, x_f, t_f)
    loss_phys = mse(f_u, torch.zeros_like(f_u)) + mse(f_v, torch.zeros_like(f_v))

    # Initial condition loss
    u_pred_i, v_pred_i = model(x_i, t_i)
    loss_init = mse(u_pred_i, u_i) + mse(v_pred_i, v_i)

    # Boundary condition loss
    u_left, v_left = model(x_b_left, t_b)
    u_right, v_right = model(x_b_right, t_b)
    loss_bc = (
        mse(u_left, torch.zeros_like(u_left)) +
        mse(v_left, torch.zeros_like(v_left)) +
        mse(u_right, torch.zeros_like(u_right)) +
        mse(v_right, torch.zeros_like(v_right))
    )

    # Total loss
    loss = loss_phys + loss_init + loss_bc
    loss.backward()
    optimizer.step()

    if epoch % 300 == 0:
        print(
            f"Epoch {epoch:5d} | "
            f"Total Loss: {loss.item():.6f} | "
            f"Physics: {loss_phys.item():.6f} | "
            f"Init: {loss_init.item():.6f} | "
            f"BC: {loss_bc.item():.6f}"
        )

print("Training complete.")

# -------------------------------
# Test prediction
# -------------------------------
x_test = torch.linspace(-5, 5, 200, device=device).reshape(-1, 1)
t_test = 0.5 * torch.ones_like(x_test)

with torch.no_grad():
    u_pred, v_pred = model(x_test, t_test)
    psi_magnitude = torch.sqrt(u_pred**2 + v_pred**2)

print("Sample |psi| values:")
print(psi_magnitude[:10].cpu().numpy())